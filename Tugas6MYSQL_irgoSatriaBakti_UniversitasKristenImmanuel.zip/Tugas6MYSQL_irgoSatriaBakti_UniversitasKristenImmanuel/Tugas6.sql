DELIMITER $$
CREATE FUNCTION kategori_harga(harga DOUBLE) RETURNS VARCHAR(20)
BEGIN
    DECLARE kategori VARCHAR(20);

    CASE
        WHEN harga <= 500000 THEN SET kategori = 'murah';
        WHEN harga > 500000 AND harga <= 3000000 THEN SET kategori = 'sedang';
        WHEN harga > 3000000 AND harga <= 10000000 THEN SET kategori = 'mahal';
        ELSE SET kategori = 'sangat mahal';
    END CASE;

    RETURN kategori;
END$$
DELIMITER ;



SELECT nama, harga_jual, kategori_harga(harga_jual) AS kategori FROM produk;
